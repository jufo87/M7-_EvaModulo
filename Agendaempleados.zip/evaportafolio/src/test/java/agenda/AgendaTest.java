package agenda;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AgendaTest {
    private Agenda agenda;

    @BeforeEach
    void setUp() {
        agenda = new Agenda();
    }

    @Test
    void testAgregarTarea() {
        Tarea t = new Tarea("Reunión con RRHH", LocalDate.of(2025, 9, 20), Estado.PENDIENTE);
        agenda.agregarTarea(t);
        List<Tarea> todas = agenda.listarTodas();
        assertEquals(1, todas.size());
        assertEquals(t.getId(), todas.get(0).getId());
    }

    @Test
    void testFiltrarPorEstado() {
        Tarea t1 = new Tarea("Tarea A", LocalDate.now(), Estado.PENDIENTE);
        Tarea t2 = new Tarea("Tarea B", LocalDate.now(), Estado.COMPLETADA);
        agenda.agregarTarea(t1);
        agenda.agregarTarea(t2);

        List<Tarea> pendientes = agenda.filtrarPorEstado(Estado.PENDIENTE);
        List<Tarea> completadas = agenda.filtrarPorEstado(Estado.COMPLETADA);

        assertEquals(1, pendientes.size());
        assertEquals(t1.getId(), pendientes.get(0).getId());

        assertEquals(1, completadas.size());
        assertEquals(t2.getId(), completadas.get(0).getId());
    }

    @Test
    void testMarcarCompletada() {
        Tarea t = new Tarea("Finalizar reporte", LocalDate.now(), Estado.PENDIENTE);
        agenda.agregarTarea(t);
        boolean marcado = agenda.marcarCompletada(t.getId());
        assertTrue(marcado);
        assertEquals(Estado.COMPLETADA, agenda.buscarPorId(t.getId()).get().getEstado());
    }

    @Test
    void testMarcarCompletada_IdInexistente() {
        boolean resultado = agenda.marcarCompletada("id-no-existe");
        assertFalse(resultado);
    }
}
