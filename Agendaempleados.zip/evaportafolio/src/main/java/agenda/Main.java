package agenda;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Agenda agenda = new Agenda();

    public static void main(String[] args) {
        System.out.println("=== Agenda de Empleados (Consola) ===");
        boolean salir = false;
        while (!salir) {
            mostrarMenu();
            String opcion = scanner.nextLine().trim();
            switch (opcion) {
                case "1": opcionAgregar(); break;
                case "2": opcionListar(); break;
                case "3": opcionFiltrar(); break;
                case "4": opcionMarcarCompletada(); break;
                case "5": salir = true; System.out.println("Saliendo. ¡Hasta luego!"); break;
                default: System.out.println("Opción inválida. Intenta de nuevo.");
            }
        }
        scanner.close();
    }

    private static void mostrarMenu() {
        System.out.println("\nSeleccione una opción:");
        System.out.println("1. Agregar tarea");
        System.out.println("2. Listar todas las tareas");
        System.out.println("3. Filtrar por estado");
        System.out.println("4. Marcar tarea como completada");
        System.out.println("5. Salir");
        System.out.print("Opción: ");
    }

    private static void opcionAgregar() {
        try {
            System.out.print("Descripción: ");
            String descripcion = scanner.nextLine().trim();
            System.out.print("Fecha (YYYY-MM-DD): ");
            String fechaStr = scanner.nextLine().trim();
            LocalDate fecha = LocalDate.parse(fechaStr);
            Tarea tarea = new Tarea(descripcion, fecha, Estado.PENDIENTE);
            agenda.agregarTarea(tarea);
            System.out.println("Tarea agregada con id: " + tarea.getId());
        } catch (DateTimeParseException e) {
            System.out.println("Fecha inválida. Use formato YYYY-MM-DD.");
        } catch (Exception e) {
            System.out.println("Error al agregar tarea: " + e.getMessage());
        }
    }

    private static void opcionListar() {
        List<Tarea> lista = agenda.listarTodas();
        if (lista.isEmpty()) {
            System.out.println("No hay tareas registradas.");
            return;
        }
        System.out.println("Listado de tareas:");
        lista.forEach(t -> System.out.println(t.toString()));
    }

    private static void opcionFiltrar() {
        System.out.print("Estado (PENDIENTE/COMPLETADA): ");
        String estadoStr = scanner.nextLine().trim().toUpperCase();
        try {
            Estado estado = Estado.valueOf(estadoStr);
            List<Tarea> filtradas = agenda.filtrarPorEstado(estado);
            if (filtradas.isEmpty()) {
                System.out.println("No hay tareas con estado " + estado);
            } else {
                filtradas.forEach(t -> System.out.println(t.toString()));
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Estado inválido. Use PENDIENTE o COMPLETADA.");
        }
    }

    private static void opcionMarcarCompletada() {
        System.out.print("Id de la tarea a marcar como completada: ");
        String id = scanner.nextLine().trim();
        boolean exito = agenda.marcarCompletada(id);
        if (exito) {
            System.out.println("Tarea marcada como completada.");
        } else {
            System.out.println("No se encontró tarea con id: " + id);
        }
    }
}
