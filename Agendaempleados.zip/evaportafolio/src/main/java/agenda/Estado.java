package agenda;

public enum Estado {
    PENDIENTE,
    COMPLETADA
}
