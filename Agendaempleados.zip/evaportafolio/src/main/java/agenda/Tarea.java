package agenda;

import java.time.LocalDate;
import java.util.Objects;
import java.util.UUID;

public class Tarea {
    private final String id;
    private String descripcion;
    private LocalDate fecha;
    private Estado estado;

    public Tarea(String descripcion, LocalDate fecha, Estado estado) {
        this.id = UUID.randomUUID().toString();
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.estado = estado;
    }

    public String getId() { return id; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
    public Estado getEstado() { return estado; }
    public void setEstado(Estado estado) { this.estado = estado; }

    public void marcarCompletada() {
        this.estado = Estado.COMPLETADA;
    }

    @Override
    public String toString() {
        return String.format("Tarea{id=%s, descripcion='%s', fecha=%s, estado=%s}",
                id, descripcion, fecha, estado);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tarea tarea = (Tarea) o;
        return Objects.equals(id, tarea.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
