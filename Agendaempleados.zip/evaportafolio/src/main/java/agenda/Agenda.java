package agenda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Agenda {
    private final List<Tarea> tareas;

    public Agenda() {
        this.tareas = new ArrayList<>();
    }

    public void agregarTarea(Tarea tarea) {
        if (tarea == null) throw new IllegalArgumentException("La tarea no puede ser null");
        tareas.add(tarea);
    }

    public List<Tarea> listarTodas() {
        return Collections.unmodifiableList(new ArrayList<>(tareas));
    }

    public List<Tarea> filtrarPorEstado(Estado estado) {
        return tareas.stream()
                .filter(t -> t.getEstado() == estado)
                .collect(Collectors.toList());
    }

    public Optional<Tarea> buscarPorId(String id) {
        return tareas.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst();
    }

    public boolean marcarCompletada(String id) {
        Optional<Tarea> opt = buscarPorId(id);
        if (opt.isPresent()) {
            opt.get().marcarCompletada();
            return true;
        }
        return false;
    }

    public void clear() { tareas.clear(); }
}
